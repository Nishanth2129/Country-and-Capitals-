//
//  DetailsViewController.swift
//  Country Capitals
//
//  Created by Padmasri Nishanth on 9/15/20.
//  Copyright © 2020 CodeWhiskey. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    
    @IBOutlet weak var alpha2Label: UILabel!
    @IBOutlet weak var alpha3Label: UILabel!
    @IBOutlet weak var regionLabel: UILabel!
    @IBOutlet weak var subregionLabel: UILabel!
    
    // whenEver we wanna parse the region, we use string
    var stralpha2 = ""
    var stralpha3 = ""
    var strregion = ""
    var strsubregion = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        alpha2Label.text = stralpha2
        alpha3Label.text = stralpha3
        regionLabel.text = strregion
        subregionLabel.text = strsubregion

    }
    

}
