//
//  ViewController.swift
//  Country Capitals
//
//  Created by Padmasri Nishanth on 9/14/20.
//  Copyright © 2020 CodeWhiskey. All rights reserved.
//

import UIKit

// Creating a Structure for JSON Data
struct jsonstruct : Decodable{
    let name: String
    let capital: String
    let alpha2Code: String
    let alpha3Code : String
    let region : String
    let subregion : String
}

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    // Initialising the structure inside the array
        var arrData = [jsonstruct]()
    
    // tableView Outlet
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
            // Function Calling
            getJSONData()
        
        // Declaring the delegate and dataSource for the tableView
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func getJSONData(){
        // Declaring the url as a string
        let urlString = "https://restcountries.eu/rest/v2/all"
        let url = URL(string: urlString)
        // creating the urlSession
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
        do{ if error == nil {
                        self.arrData = try JSONDecoder().decode([jsonstruct].self, from: data!)
                        // Creating a for loop for the display of coutries
                        for mainArray in self.arrData {
                        print(mainArray.name,":",mainArray.capital)
                        DispatchQueue.main.async {
                                 self.tableView.reloadData()
                            }

            }
            }
            }
            catch{
                print("Error in the JSON Parsing ")
            }
         // Resuming the dataTask
        }.resume()
    }
    
    // TableView functions
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return self.arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.nameLabel.text = "Name: \(arrData[indexPath.row].name)"
        cell.capitalLabel.text = "Capital: \(arrData[indexPath.row].capital)"
        return cell
    }
    
    //tableView func for the details view controller
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detail:DetailsViewController = storyboard?.instantiateViewController(identifier: "detail") as! DetailsViewController
        detail.stralpha2 = "Alpha2Code: \(arrData[indexPath.row].alpha2Code)"
        detail.stralpha3 =  "Alpha3Code: \(arrData[indexPath.row].alpha3Code)"
        detail.strregion = "Region: \(arrData[indexPath.row].region)"
        detail.strsubregion = "SubRegion: \(arrData[indexPath.row].subregion)"
        self.navigationController?.pushViewController(detail, animated: true)
    }

}

